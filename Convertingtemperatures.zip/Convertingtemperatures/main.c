#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <math.h>

#define K 1.8
#define T 32
int main()
{
    double Fahrenheit;
    double Celsius;

    printf ("Enter the Temperature in Celsius: ");
    scanf ("%lf", &Celsius);

    Fahrenheit = (K * Celsius) / 5 + T;

    printf ("The Temperature in Fahrenheit is: %.2lf\n", Fahrenheit);

    return 0;
}
