#include <stdio.h>
#include <stdlib.h>

// Creating a Function to check if a given year is a leap year or not
int isaLeapYear(int year) {
    // In order to get a Leap year the conditions are :
    // 1. The given year should be divisible by 4
    // 2. If the year is divisible by 100, it should also be divisible by 400

    // Checking if the year is modulos 4
    if (year % 4 == 0) {
        // If the year is modulos 100,
        if (year % 100 == 0) {
            if (year % 400 == 0) // Also check modulos 400 for that given year to be a leap year

                return 1; // Leap year if the given year is modulos 400
            else
                return 0; // Not a leap year if the givenyear if not modulos 400
        } else {
            return 1; // Leap year if not modulos 100 (and its already leap year if modulos 4)
        }
    } else {
        return 0; // Not a leap year if not modulos 4
    }
}

int main() {
    int year;

    // Giving the input year
    printf("Enter a year: ");
    scanf("%d", &year);

    // Function calling to check if the year is a leap year
    if (isaLeapYear(year)) {
        printf("%d is a leap year.\n", year);
    } else {
        printf("%d is not a leap year.\n", year);
    }

    return 0;
}

