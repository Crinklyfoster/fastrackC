#include <stdio.h>

// Function to reverse the digits of a number
int reverse_number(int number) {
    int reversed = 0; // Variable to store the reversed number
    int original_number = number; // Store the original number for reference

    // Loop until the number becomes 0
    while (number > 0) {
        // Extract the last digit of the number
        int digit = number % 10;

        // Add the digit to the reversed number, shifting the previous digits
        reversed = reversed * 10 + digit;

        // Remove the last digit from the number
        number /= 10;
    }

    // Return the reversed number
    return reversed;
}

int main() {
    int number;

    // Prompt the user to enter a number
    printf("Enter a number: ");
    scanf("%d", &number);

    // Call the reverse_number function to reverse the digits of the number
    int reversed = reverse_number(number);

    // Print the reversed number
    printf("The reversed number is: %d\n", reversed);

    return 0;
}
