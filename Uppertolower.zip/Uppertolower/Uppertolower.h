#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

int main()
{
   char upper, lower; //Declaring the variables
   int ascii;
}
