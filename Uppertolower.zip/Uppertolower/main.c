#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

int main()
{
   char upper, lower; //Declaring the variables
   int ascii;

   //convert the input to lower case

   printf (" Enter the Upper Case Character: ");
    scanf (" %c", &upper);
    ascii = upper + 32;
    printf (" %c character in Lower case is: %c", upper, ascii);

  // convert the input to upper case

    printf (" \n Enter the Lower Case Character: ");
    scanf (" %c", &lower);
    ascii = lower - 32;
    printf (" %c character in the Upper case is: %c", lower, ascii);

    return 0;
}
