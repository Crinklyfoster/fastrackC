#include <stdio.h>

// Function to check if a number is a palindrome
int is_palindrome(int number) {
    int original_number = number; // Store the original number
    int reversed = 0; // Variable to store the reversed number

    // Reverse the number
    while (number > 0) {
        reversed = reversed * 10 + (number % 10);
        number /= 10;
    }

    // Return 1 if palindrome, otherwise 0
    return reversed == original_number;
}

int main() {
    int number;

    // Input and check
    printf("Enter a number: ");
    scanf("%d", &number);

    // Output result
    if (is_palindrome(number)) {
        printf("%d is a palindrome.\n", number);
    } else {
        printf("%d is not a palindrome.\n", number);
    }

    return 0;
}
