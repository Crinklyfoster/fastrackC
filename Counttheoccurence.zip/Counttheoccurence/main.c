#include <stdio.h>

// Function to count the occurrences of a specific digit in a number
int count_digit_occurrences(int number, int digit) {
    int count = 0; // Variable to store the count of occurrences

    // Loop until the number becomes 0
    while (number > 0) {
        // Extract the last digit of the number
        int current_digit = number % 10;

        // Check if the extracted digit matches the target digit
        if (current_digit == digit) {
            count++; // Increment count if there is a match
        }

        // Remove the last digit from the number
        number /= 10;
    }

    // Return the count of occurrences
    return count;
}

int main() {
    int number, digit;

    // Prompt the user to enter a number
    printf("Enter a number: ");
    scanf("%d", &number);

    // Prompt the user to enter the digit to count
    printf("Enter the digit to count (0-9): ");
    scanf("%d", &digit);

    // Validate the digit input
    if (digit < 0 || digit > 9) {
        printf("Invalid digit. Please enter a digit between 0 and 9.\n");
        return 1; // Exit the program with an error code
    }

    // Call the count_digit_occurrences function to count the occurrences of the digit
    int count = count_digit_occurrences(number, digit);

    // Print the count of occurrences
    printf("The digit %d occurs %d times in the number %d.\n", digit, count, number);

    return 0;
}

