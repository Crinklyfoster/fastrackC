#include <stdio.h>
#include <stdlib.h>

#include <stdio.h>

// Function to calculate the sum of digits of a number
int sum_of_digits(int number) {
    int sum = 0;

    // Loop until the number becomes 0
    while (number > 0) {
        // Extract the last digit of the number
        int digit = number % 10;

        // Add the digit to the sum
        sum += digit;

        // Remove the last digit from the number
        number /= 10;
    }

    // Return the total sum of digits
    return sum;
}

int main() {
    int number;

    // Prompt the user to enter a 5-digit number
    while (1) {
        printf("Enter a 5-digit number: ");
        scanf("%d", &number);

        // Check if the entered number is a 5-digit number
        if (number >= 10000 && number <= 99999) {
            break;
        } else {
            printf("Please enter a valid 5-digit number.\n");
        }
    }

    // Calculate the sum of digits using the function
    int result = sum_of_digits(number);

    // Print the sum of digits
    printf("The sum of the digits is: %d\n", result);

    return 0;
}

