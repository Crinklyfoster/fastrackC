#include <stdio.h>
#include <stdlib.h>

#include <stdio.h>

// Function to check if a number is even or odd
void checkifEvenorOdd(int num) {

    // Check if number modulos 2 is equal to 0
    if (num % 2 == 0) {
        printf("%d is even.\n", num);
    } else {
        printf("%d is odd.\n", num);
    }
}

int main() {
    int number;

    // Input from user
    printf("Enter an integer: ");
    scanf("%d", &number);

    // Function call to check if the number is even or odd
    checkifEvenorOdd(number);

    return 0;
}

