#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main() {
    int num1, num2;
    int sum;

    // Seed the random number generator with the current time
    srand(time(0));

    // Generating two random numbers between 1 and 100000
    num1 = rand() % 100000 + 1;
    num2 = rand() % 100000 + 1;

    // Calculating the sum of the two random numbers
    sum = num1 + num2;

    // Displaying the random numbers and their sum
    printf("Random number 1: %d\n", num1);
    printf("Random number 2: %d\n", num2);
    printf("Sum of the random numbers: %d\n", sum);

    return 0;
}
