#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <stdlib.h>

#define pi 3.141592

int main()
{
  float r, area; //Declaring the variables

 //Calculating the area of the circle

  printf (" Enter the value of r: ");
    scanf (" %f", &r);

    area = pi*r*r;

//displaying the result
 printf("the area of the circle is:%f",area);

  return 0;
}


